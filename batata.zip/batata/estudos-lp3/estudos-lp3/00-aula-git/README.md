# Estudo LP3

Este repositório tem como objetivo armazenar e controlar os códigos da disciplina de LP3

## Aulas

- Aula 00 - Git e GitHub
 -Aula 01 - Introdução ao Python