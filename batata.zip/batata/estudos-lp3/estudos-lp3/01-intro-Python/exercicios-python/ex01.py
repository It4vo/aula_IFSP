valor = int(input('Digite um número: '))

print(f'Sucessor -> {valor+1}')
print(f'Antecessor -> {valor-1}')