a = float(input('Digite o primeiro número: '))
b = float(input('Digite o segundo número: '))
c = float(input('Digite o terceiro número: '))

print(f'A média dos 3 valores é: {(a+b+c) / 3:.2f}')