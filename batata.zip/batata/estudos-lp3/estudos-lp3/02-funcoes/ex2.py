def tabuada():

    valor = int(input('Digite um número: '))

    for i in range(1, 11):

        print(f'{i} X {valor} = {i*valor}')

tabuada()