def calcIMC(altura, peso):

    return peso / (altura*altura)

def pesoIdeal(altura):

    return altura*altura*24.9